**Arquivo: V000_part_cut / Raio = 1/ Nº elementos = 50000 / Execuções = 30 / T exec interno = s / Metódo 0 /  threads / Save = s**
 
| Interno | Externo |
|---------| ------- |
|29.5031 segundos |29.5076 segundos |
|29.4309 segundos |29.4351 segundos |
|29.4968 segundos |29.5012 segundos |
|29.4375 segundos |29.4421 segundos |
|29.4292 segundos |29.4338 segundos |
|29.4241 segundos |29.4284 segundos |
|29.4291 segundos |29.4332 segundos |
|29.4267 segundos |29.4314 segundos |
|29.4331 segundos |29.4374 segundos |
|29.4547 segundos |29.459 segundos |
|29.4303 segundos |29.4346 segundos |
|29.6322 segundos |29.6367 segundos |
|29.43 segundos |29.4345 segundos |
|29.4307 segundos |29.4349 segundos |
|29.8091 segundos |29.8137 segundos |
|29.568 segundos |29.5723 segundos |
|30.5708 segundos |30.5754 segundos |
|29.428 segundos |29.4323 segundos |
|29.4808 segundos |29.4852 segundos |
|29.4286 segundos |29.4329 segundos |
|29.4281 segundos |29.4324 segundos |
|29.4298 segundos |29.4341 segundos |
|29.4245 segundos |29.4291 segundos |
|29.4284 segundos |29.4323 segundos |
|29.4293 segundos |29.4329 segundos |
|29.4868 segundos |29.4905 segundos |
|29.4296 segundos |29.4341 segundos |
|29.4972 segundos |29.5016 segundos |
|29.4304 segundos |29.4347 segundos |
|29.4967 segundos |29.5011 segundos |

|Menor|Maior|Média|
|------|------|------|
|Interno = 29.4241 segundos |Interno = 30.5708 segundos |Interno = 29.5052 segundos |
|Externo = 29.4284 segundos |Externo = 30.5754 segundos |Externo = 29.5095 segundos |
```<code>
Arquitetura:           x86_64
Modo(s) operacional da CPU:32-bit, 64-bit
Ordem dos bytes:       Little Endian
CPU(s):                8
Lista de CPU(s) on-line:0-7
Thread(s) per núcleo  2
Núcleo(s) por soquete:4
Soquete(s):            1
Nó(s) de NUMA:        1
ID de fornecedor:      GenuineIntel
Família da CPU:       6
Modelo:                44
Nome do modelo:        Intel(R) Xeon(R) CPU           E5620  @ 2.40GHz
Step:                  2
CPU MHz:               1600.000
CPU MHz máx.:         2401,0000
CPU MHz mín.:         1600,0000
BogoMIPS:              4800.13
Virtualização:       VT-x
cache de L1d:          32K
cache de L1i:          32K
cache de L2:           256K
cache de L3:           12288K
CPU(s) de nó0 NUMA:   0-7
