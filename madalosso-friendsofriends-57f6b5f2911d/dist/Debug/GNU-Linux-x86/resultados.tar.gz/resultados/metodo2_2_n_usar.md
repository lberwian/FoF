**Arquivo: V000_part_cut / Raio = 1/ Nº elementos = 50000 / Execuções = 30 / T exec interno = s / Metódo 2 / 2 threads / Save = s**
 
| Interno | Externo |
|---------| ------- |
|6.60966 segundos |6.61467 segundos |
|6.64863 segundos |6.65346 segundos |
|6.67498 segundos |6.67918 segundos |
|6.54556 segundos |6.54963 segundos |
|6.63356 segundos |6.63833 segundos |
|6.63641 segundos |6.64139 segundos |
|6.53183 segundos |6.53691 segundos |
|6.54265 segundos |6.5477 segundos |
|6.60129 segundos |6.60607 segundos |
|6.53145 segundos |6.53646 segundos |
|6.67738 segundos |6.68232 segundos |
|6.62151 segundos |6.62627 segundos |
|6.55367 segundos |6.55867 segundos |
|6.71457 segundos |6.71944 segundos |
|6.66856 segundos |6.67347 segundos |
|6.63375 segundos |6.63849 segundos |
|6.61179 segundos |6.61659 segundos |
|6.66359 segundos |6.66868 segundos |
|6.53339 segundos |6.53841 segundos |
|6.61088 segundos |6.61574 segundos |
|6.61822 segundos |6.62295 segundos |
|6.66164 segundos |6.6663 segundos |
|6.58134 segundos |6.58634 segundos |
|6.61665 segundos |6.62131 segundos |
|6.62684 segundos |6.63173 segundos |
|6.60635 segundos |6.61117 segundos |
|15.3783 segundos |15.3831 segundos |
|6.62587 segundos |6.63072 segundos |
|6.79416 segundos |6.79922 segundos |
|6.69613 segundos |6.70113 segundos |

|Menor|Maior|Média|
|------|------|------|
|Interno = 6.53145 segundos |Interno = 15.3783 segundos |Interno = 6.91502 segundos |
|Externo = 6.53646 segundos |Externo = 15.3831 segundos |Externo = 6.91986 segundos |
```<code>
Arquitetura:           x86_64
Modo(s) operacional da CPU:32-bit, 64-bit
Ordem dos bytes:       Little Endian
CPU(s):                8
Lista de CPU(s) on-line:0-7
Thread(s) per núcleo  2
Núcleo(s) por soquete:4
Soquete(s):            1
Nó(s) de NUMA:        1
ID de fornecedor:      GenuineIntel
Família da CPU:       6
Modelo:                44
Nome do modelo:        Intel(R) Xeon(R) CPU           E5620  @ 2.40GHz
Step:                  2
CPU MHz:               1600.000
CPU MHz máx.:         2401,0000
CPU MHz mín.:         1600,0000
BogoMIPS:              4800.13
Virtualização:       VT-x
cache de L1d:          32K
cache de L1i:          32K
cache de L2:           256K
cache de L3:           12288K
CPU(s) de nó0 NUMA:   0-7
