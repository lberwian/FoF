**Arquivo: V000_part_cut / Raio = 1/ Nº elementos = 50000 / Execuções = 30 / T exec interno = s / Metódo 1 / 1 threads / Save = s**
 
| Interno | Externo |
|---------| ------- |
|9.4772 segundos |9.48184 segundos |
|9.52017 segundos |9.52412 segundos |
|9.28098 segundos |9.28535 segundos |
|9.34877 segundos |9.35342 segundos |
|9.57706 segundos |9.5811 segundos |
|9.61552 segundos |9.61951 segundos |
|9.45556 segundos |9.46047 segundos |
|9.30463 segundos |9.30953 segundos |
|9.70783 segundos |9.71263 segundos |
|9.47947 segundos |9.48349 segundos |
|9.3041 segundos |9.30842 segundos |
|9.28961 segundos |9.29455 segundos |
|9.54892 segundos |9.55324 segundos |
|9.47226 segundos |9.47668 segundos |
|9.34011 segundos |9.34483 segundos |
|9.30238 segundos |9.30682 segundos |
|9.6031 segundos |9.60758 segundos |
|9.6722 segundos |9.67621 segundos |
|9.47647 segundos |9.48068 segundos |
|9.31962 segundos |9.3241 segundos |
|9.49132 segundos |9.49584 segundos |
|9.53943 segundos |9.54402 segundos |
|9.45395 segundos |9.45885 segundos |
|9.28957 segundos |9.29434 segundos |
|9.66147 segundos |9.66574 segundos |
|9.47535 segundos |9.47945 segundos |
|9.45296 segundos |9.45746 segundos |
|9.40085 segundos |9.40573 segundos |
|9.53965 segundos |9.544 segundos |
|9.51271 segundos |9.51658 segundos |

|Menor|Maior|Média|
|------|------|------|
|Interno = 9.28098 segundos |Interno = 9.70783 segundos |Interno = 9.46377 segundos |
|Externo = 9.28535 segundos |Externo = 9.71263 segundos |Externo = 9.46822 segundos |
```<code>
Arquitetura:           x86_64
Modo(s) operacional da CPU:32-bit, 64-bit
Ordem dos bytes:       Little Endian
CPU(s):                8
Lista de CPU(s) on-line:0-7
Thread(s) per núcleo  2
Núcleo(s) por soquete:4
Soquete(s):            1
Nó(s) de NUMA:        1
ID de fornecedor:      GenuineIntel
Família da CPU:       6
Modelo:                44
Nome do modelo:        Intel(R) Xeon(R) CPU           E5620  @ 2.40GHz
Step:                  2
CPU MHz:               1600.000
CPU MHz máx.:         2401,0000
CPU MHz mín.:         1600,0000
BogoMIPS:              4800.13
Virtualização:       VT-x
cache de L1d:          32K
cache de L1i:          32K
cache de L2:           256K
cache de L3:           12288K
CPU(s) de nó0 NUMA:   0-7
