**Arquivo: V000_part_cut / Raio = 1/ Nº elementos = 50000 / Execuções = 30 / T exec interno = s / Metódo 2 / 1 threads / Save = s**
 
| Interno | Externo |
|---------| ------- |
|11.6297 segundos |11.6346 segundos |
|11.6327 segundos |11.6374 segundos |
|11.6328 segundos |11.6376 segundos |
|11.6296 segundos |11.6343 segundos |
|11.6361 segundos |11.6408 segundos |
|11.6261 segundos |11.6309 segundos |
|11.6322 segundos |11.637 segundos |
|11.6468 segundos |11.6516 segundos |
|11.6264 segundos |11.6312 segundos |
|11.6337 segundos |11.6384 segundos |
|11.6313 segundos |11.6363 segundos |
|11.6325 segundos |11.6373 segundos |
|11.6412 segundos |11.6461 segundos |
|11.6324 segundos |11.6372 segundos |
|11.6298 segundos |11.6346 segundos |
|11.6297 segundos |11.6342 segundos |
|11.6295 segundos |11.6343 segundos |
|11.6311 segundos |11.6358 segundos |
|11.6298 segundos |11.6344 segundos |
|11.6562 segundos |11.6611 segundos |
|11.6396 segundos |11.6447 segundos |
|11.7211 segundos |11.7259 segundos |
|11.633 segundos |11.6377 segundos |
|11.6764 segundos |11.6812 segundos |
|11.6305 segundos |11.6353 segundos |
|11.6315 segundos |11.6362 segundos |
|11.6336 segundos |11.6382 segundos |
|11.6291 segundos |11.6337 segundos |
|11.6345 segundos |11.6392 segundos |
|11.6321 segundos |11.6368 segundos |

|Menor|Maior|Média|
|------|------|------|
|Interno = 11.6261 segundos |Interno = 11.7211 segundos |Interno = 11.6377 segundos |
|Externo = 11.6309 segundos |Externo = 11.7259 segundos |Externo = 11.6425 segundos |
```<code>
Arquitetura:           x86_64
Modo(s) operacional da CPU:32-bit, 64-bit
Ordem dos bytes:       Little Endian
CPU(s):                8
Lista de CPU(s) on-line:0-7
Thread(s) per núcleo  2
Núcleo(s) por soquete:4
Soquete(s):            1
Nó(s) de NUMA:        1
ID de fornecedor:      GenuineIntel
Família da CPU:       6
Modelo:                44
Nome do modelo:        Intel(R) Xeon(R) CPU           E5620  @ 2.40GHz
Step:                  2
CPU MHz:               1600.000
CPU MHz máx.:         2401,0000
CPU MHz mín.:         1600,0000
BogoMIPS:              4800.13
Virtualização:       VT-x
cache de L1d:          32K
cache de L1i:          32K
cache de L2:           256K
cache de L3:           12288K
CPU(s) de nó0 NUMA:   0-7
