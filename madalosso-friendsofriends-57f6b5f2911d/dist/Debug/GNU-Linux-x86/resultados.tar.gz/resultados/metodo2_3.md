**Arquivo: V000_part_cut / Raio = 1/ Nº elementos = 50000 / Execuções = 30 / T exec interno = s / Metódo 2 / 3 threads / Save = s**
 
| Interno | Externo |
|---------| ------- |
|5.1094 segundos |5.11452 segundos |
|5.27194 segundos |5.27716 segundos |
|5.20983 segundos |5.215 segundos |
|5.20644 segundos |5.2115 segundos |
|5.16735 segundos |5.17244 segundos |
|5.20502 segundos |5.21021 segundos |
|5.22211 segundos |5.22727 segundos |
|5.17946 segundos |5.1845 segundos |
|5.17209 segundos |5.17723 segundos |
|5.24078 segundos |5.24558 segundos |
|5.15014 segundos |5.15532 segundos |
|5.1347 segundos |5.13979 segundos |
|5.16777 segundos |5.17292 segundos |
|5.24996 segundos |5.25489 segundos |
|5.23013 segundos |5.23531 segundos |
|5.24825 segundos |5.2534 segundos |
|5.2044 segundos |5.20943 segundos |
|5.2403 segundos |5.24529 segundos |
|5.23225 segundos |5.23725 segundos |
|5.24219 segundos |5.24695 segundos |
|5.15506 segundos |5.16034 segundos |
|5.1765 segundos |5.18135 segundos |
|5.22195 segundos |5.22712 segundos |
|5.15124 segundos |5.15623 segundos |
|5.15903 segundos |5.16418 segundos |
|5.24838 segundos |5.25355 segundos |
|5.19613 segundos |5.20118 segundos |
|5.19056 segundos |5.1957 segundos |
|5.25471 segundos |5.25967 segundos |
|5.19687 segundos |5.20219 segundos |

|Menor|Maior|Média|
|------|------|------|
|Interno = 5.1094 segundos |Interno = 5.27194 segundos |Interno = 5.20116 segundos |
|Externo = 5.11452 segundos |Externo = 5.27716 segundos |Externo = 5.20625 segundos |
```<code>
Arquitetura:           x86_64
Modo(s) operacional da CPU:32-bit, 64-bit
Ordem dos bytes:       Little Endian
CPU(s):                8
Lista de CPU(s) on-line:0-7
Thread(s) per núcleo  2
Núcleo(s) por soquete:4
Soquete(s):            1
Nó(s) de NUMA:        1
ID de fornecedor:      GenuineIntel
Família da CPU:       6
Modelo:                44
Nome do modelo:        Intel(R) Xeon(R) CPU           E5620  @ 2.40GHz
Step:                  2
CPU MHz:               1600.000
CPU MHz máx.:         2401,0000
CPU MHz mín.:         1600,0000
BogoMIPS:              4800.13
Virtualização:       VT-x
cache de L1d:          32K
cache de L1i:          32K
cache de L2:           256K
cache de L3:           12288K
CPU(s) de nó0 NUMA:   0-7
