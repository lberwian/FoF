**Arquivo: V000_part_cut / Raio = 1/ Nº elementos = 50000 / Execuções = 30 / T exec interno = s / Metódo 2 / 4 threads / Save = s**
 
| Interno | Externo |
|---------| ------- |
|4.31038 segundos |4.3158 segundos |
|4.31604 segundos |4.32118 segundos |
|4.28072 segundos |4.28593 segundos |
|4.23648 segundos |4.24168 segundos |
|4.33793 segundos |4.34314 segundos |
|4.31984 segundos |4.32485 segundos |
|4.2376 segundos |4.24272 segundos |
|4.32903 segundos |4.33407 segundos |
|4.36929 segundos |4.37454 segundos |
|4.32816 segundos |4.33352 segundos |
|4.28263 segundos |4.28786 segundos |
|4.3144 segundos |4.31931 segundos |
|4.30234 segundos |4.3074 segundos |
|4.33418 segundos |4.33906 segundos |
|4.28736 segundos |4.29253 segundos |
|4.31591 segundos |4.32112 segundos |
|4.31812 segundos |4.32339 segundos |
|4.35629 segundos |4.36132 segundos |
|4.35688 segundos |4.36203 segundos |
|4.61271 segundos |4.61783 segundos |
|4.30619 segundos |4.31146 segundos |
|4.27771 segundos |4.28294 segundos |
|4.31451 segundos |4.31967 segundos |
|4.32697 segundos |4.33217 segundos |
|4.3419 segundos |4.34719 segundos |
|4.33352 segundos |4.33875 segundos |
|4.24236 segundos |4.24758 segundos |
|4.23727 segundos |4.24221 segundos |
|4.34624 segundos |4.3512 segundos |
|4.30857 segundos |4.31375 segundos |

|Menor|Maior|Média|
|------|------|------|
|Interno = 4.23648 segundos |Interno = 4.61271 segundos |Interno = 4.31938 segundos |
|Externo = 4.24168 segundos |Externo = 4.61783 segundos |Externo = 4.32454 segundos |
```<code>
Arquitetura:           x86_64
Modo(s) operacional da CPU:32-bit, 64-bit
Ordem dos bytes:       Little Endian
CPU(s):                8
Lista de CPU(s) on-line:0-7
Thread(s) per núcleo  2
Núcleo(s) por soquete:4
Soquete(s):            1
Nó(s) de NUMA:        1
ID de fornecedor:      GenuineIntel
Família da CPU:       6
Modelo:                44
Nome do modelo:        Intel(R) Xeon(R) CPU           E5620  @ 2.40GHz
Step:                  2
CPU MHz:               1600.000
CPU MHz máx.:         2401,0000
CPU MHz mín.:         1600,0000
BogoMIPS:              4800.13
Virtualização:       VT-x
cache de L1d:          32K
cache de L1i:          32K
cache de L2:           256K
cache de L3:           12288K
CPU(s) de nó0 NUMA:   0-7
