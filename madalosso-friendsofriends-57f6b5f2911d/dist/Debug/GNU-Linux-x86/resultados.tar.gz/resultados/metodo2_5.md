**Arquivo: V000_part_cut / Raio = 1/ Nº elementos = 50000 / Execuções = 30 / T exec interno = s / Metódo 2 / 5 threads / Save = s**
 
| Interno | Externo |
|---------| ------- |
|3.91924 segundos |3.9243 segundos |
|3.98934 segundos |3.99455 segundos |
|3.92159 segundos |3.92621 segundos |
|4.02087 segundos |4.02578 segundos |
|4.04136 segundos |4.04607 segundos |
|3.88937 segundos |3.89439 segundos |
|4.01392 segundos |4.01873 segundos |
|4.02808 segundos |4.03321 segundos |
|3.90612 segundos |3.91125 segundos |
|3.98936 segundos |3.9945 segundos |
|3.87801 segundos |3.88284 segundos |
|4.04453 segundos |4.04963 segundos |
|4.01873 segundos |4.02369 segundos |
|3.90565 segundos |3.91087 segundos |
|3.88985 segundos |3.89502 segundos |
|3.93242 segundos |3.93763 segundos |
|3.98536 segundos |3.99041 segundos |
|3.89289 segundos |3.89793 segundos |
|4.03401 segundos |4.03865 segundos |
|3.90684 segundos |3.91179 segundos |
|3.91157 segundos |3.91655 segundos |
|3.87405 segundos |3.87916 segundos |
|3.98773 segundos |3.99263 segundos |
|3.92352 segundos |3.92837 segundos |
|4.08769 segundos |4.09249 segundos |
|3.82481 segundos |3.82974 segundos |
|3.8333 segundos |3.83839 segundos |
|3.84148 segundos |3.8466 segundos |
|3.87788 segundos |3.88268 segundos |
|4.00784 segundos |4.01234 segundos |

|Menor|Maior|Média|
|------|------|------|
|Interno = 3.82481 segundos |Interno = 4.08769 segundos |Interno = 3.94591 segundos |
|Externo = 3.82974 segundos |Externo = 4.09249 segundos |Externo = 3.95088 segundos |
```<code>
Arquitetura:           x86_64
Modo(s) operacional da CPU:32-bit, 64-bit
Ordem dos bytes:       Little Endian
CPU(s):                8
Lista de CPU(s) on-line:0-7
Thread(s) per núcleo  2
Núcleo(s) por soquete:4
Soquete(s):            1
Nó(s) de NUMA:        1
ID de fornecedor:      GenuineIntel
Família da CPU:       6
Modelo:                44
Nome do modelo:        Intel(R) Xeon(R) CPU           E5620  @ 2.40GHz
Step:                  2
CPU MHz:               1600.000
CPU MHz máx.:         2401,0000
CPU MHz mín.:         1600,0000
BogoMIPS:              4800.13
Virtualização:       VT-x
cache de L1d:          32K
cache de L1i:          32K
cache de L2:           256K
cache de L3:           12288K
CPU(s) de nó0 NUMA:   0-7
