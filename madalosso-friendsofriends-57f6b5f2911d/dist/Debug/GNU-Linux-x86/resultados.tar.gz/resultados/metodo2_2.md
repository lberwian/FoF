**Arquivo: V000_part_cut / Raio = 1/ Nº elementos = 50000 / Execuções = 30 / T exec interno = s / Metódo 2 / 2 threads / Save = s**
 
| Interno | Externo |
|---------| ------- |
|6.51882 segundos |6.52357 segundos |
|6.5431 segundos |6.54792 segundos |
|6.64321 segundos |6.64796 segundos |
|6.62019 segundos |6.62523 segundos |
|6.6139 segundos |6.61902 segundos |
|6.6557 segundos |6.6605 segundos |
|6.70547 segundos |6.71046 segundos |
|6.6283 segundos |6.63307 segundos |
|6.64229 segundos |6.64699 segundos |
|6.51574 segundos |6.52053 segundos |
|6.65629 segundos |6.6611 segundos |
|6.65729 segundos |6.66207 segundos |
|6.62326 segundos |6.62796 segundos |
|6.65376 segundos |6.65875 segundos |
|6.60588 segundos |6.6107 segundos |
|6.51923 segundos |6.52427 segundos |
|6.79764 segundos |6.80228 segundos |
|6.655 segundos |6.6599 segundos |
|6.64357 segundos |6.64845 segundos |
|6.64103 segundos |6.64605 segundos |
|6.54904 segundos |6.55408 segundos |
|6.65575 segundos |6.66074 segundos |
|6.53034 segundos |6.53527 segundos |
|6.54114 segundos |6.54607 segundos |
|6.5381 segundos |6.54231 segundos |
|6.54001 segundos |6.54416 segundos |
|6.66128 segundos |6.66603 segundos |
|6.59597 segundos |6.6008 segundos |
|6.66347 segundos |6.66831 segundos |
|6.64163 segundos |6.64661 segundos |

|Menor|Maior|Média|
|------|------|------|
|Interno = 6.51574 segundos |Interno = 6.79764 segundos |Interno = 6.61521 segundos |
|Externo = 6.52053 segundos |Externo = 6.80228 segundos |Externo = 6.62004 segundos |
```<code>
Arquitetura:           x86_64
Modo(s) operacional da CPU:32-bit, 64-bit
Ordem dos bytes:       Little Endian
CPU(s):                8
Lista de CPU(s) on-line:0-7
Thread(s) per núcleo  2
Núcleo(s) por soquete:4
Soquete(s):            1
Nó(s) de NUMA:        1
ID de fornecedor:      GenuineIntel
Família da CPU:       6
Modelo:                44
Nome do modelo:        Intel(R) Xeon(R) CPU           E5620  @ 2.40GHz
Step:                  2
CPU MHz:               1600.000
CPU MHz máx.:         2401,0000
CPU MHz mín.:         1600,0000
BogoMIPS:              4800.13
Virtualização:       VT-x
cache de L1d:          32K
cache de L1i:          32K
cache de L2:           256K
cache de L3:           12288K
CPU(s) de nó0 NUMA:   0-7
