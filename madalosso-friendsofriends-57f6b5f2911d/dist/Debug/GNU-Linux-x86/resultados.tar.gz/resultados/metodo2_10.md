**Arquivo: V000_part_cut / Raio = 1/ Nº elementos = 50000 / Execuções = 30 / T exec interno = s / Metódo 2 / 10 threads / Save = s**
 
| Interno | Externo |
|---------| ------- |
|3.94168 segundos |3.94689 segundos |
|3.97619 segundos |3.98145 segundos |
|4.00686 segundos |4.01213 segundos |
|3.99559 segundos |4.00092 segundos |
|3.95351 segundos |3.95857 segundos |
|4.20665 segundos |4.21171 segundos |
|4.0247 segundos |4.02978 segundos |
|3.83972 segundos |3.8447 segundos |
|3.98973 segundos |3.99495 segundos |
|3.92864 segundos |3.93264 segundos |
|3.86796 segundos |3.87266 segundos |
|3.82339 segundos |3.82872 segundos |
|3.93012 segundos |3.93489 segundos |
|3.96327 segundos |3.96831 segundos |
|4.02016 segundos |4.02521 segundos |
|3.95806 segundos |3.96322 segundos |
|4.02368 segundos |4.0285 segundos |
|4.04034 segundos |4.04492 segundos |
|3.97125 segundos |3.97641 segundos |
|3.98073 segundos |3.98603 segundos |
|3.95436 segundos |3.9596 segundos |
|4.02829 segundos |4.03367 segundos |
|3.98844 segundos |3.9937 segundos |
|3.99257 segundos |3.9979 segundos |
|3.72474 segundos |3.72992 segundos |
|3.81712 segundos |3.82196 segundos |
|3.75655 segundos |3.76185 segundos |
|4.00348 segundos |4.00788 segundos |
|4.00341 segundos |4.00856 segundos |
|4.02803 segundos |4.0331 segundos |

|Menor|Maior|Média|
|------|------|------|
|Interno = 3.72474 segundos |Interno = 4.20665 segundos |Interno = 3.95797 segundos |
|Externo = 3.72992 segundos |Externo = 4.21171 segundos |Externo = 3.96303 segundos |
```<code>
Arquitetura:           x86_64
Modo(s) operacional da CPU:32-bit, 64-bit
Ordem dos bytes:       Little Endian
CPU(s):                8
Lista de CPU(s) on-line:0-7
Thread(s) per núcleo  2
Núcleo(s) por soquete:4
Soquete(s):            1
Nó(s) de NUMA:        1
ID de fornecedor:      GenuineIntel
Família da CPU:       6
Modelo:                44
Nome do modelo:        Intel(R) Xeon(R) CPU           E5620  @ 2.40GHz
Step:                  2
CPU MHz:               1600.000
CPU MHz máx.:         2401,0000
CPU MHz mín.:         1600,0000
BogoMIPS:              4800.13
Virtualização:       VT-x
cache de L1d:          32K
cache de L1i:          32K
cache de L2:           256K
cache de L3:           12288K
CPU(s) de nó0 NUMA:   0-7
